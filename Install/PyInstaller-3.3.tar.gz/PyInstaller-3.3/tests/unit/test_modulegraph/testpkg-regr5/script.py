import __init__

from PyInstaller.lib.modulegraph.find_modules import find_needed_modules
import distutils
