""" pkg.subpkg.mod2 """
from __future__ import absolute_import
from ..sub2.mod import __doc__
from ..sub2 import mod
