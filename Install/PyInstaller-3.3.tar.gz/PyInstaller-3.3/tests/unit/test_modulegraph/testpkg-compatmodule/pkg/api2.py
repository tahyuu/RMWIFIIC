import urllib2

def div(a, b):
    try:
        return a/b

    except ZeroDivisionError, exc:
        return None

class MyClass (object):
    pass
